from tkinter import *
from tkinter import messagebox
from tkinter import scrolledtext
import os,time,random
import pygit
pygit.repos()
rep='github.com/GoodManVip/PyChat_1.6.2'
pygit.load()
