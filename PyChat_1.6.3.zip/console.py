#Console
import os,time,random
from tkinter import *
from tkinter import scrolledtext

class db():
    def write(text,dbname):
        db=open(dbname+'.db')
        dump=db.read();
        db.close()
        db=open(dbname+'.db','w')
        db.write(dump)
        db.write(text+'\n')
        db.close()
    def dumpall(dbname):
        db=open(dbname+'.db')
        dump=db.read();
        db.close()
        return dump
    def dumpip(ip,dbname):
        db=open(dbname+'.db')
        for i in db.readlines():
            if i.split('=')[1]==ip:
                print(i)
    def createdb(dbname):
        dbname=dbname+'.db'
        db=open(dbname,'w+')
        db.close()

def execute(com):
    if com.split(' ')[0] == 'ping':
        os.system('ping '+com.split(' ')[1])
        console.insert(INSERT,'ping '+com.split(' ')[1]+'\n')
    if com.split(' ')[0] == 'db':
        if com.split(' ')[1] == 'write':
            db.write(com.split(' ')[3],com.split(' ')[2])
            console.insert(INSERT,'Db suucefull updated!'+'\n')
        if com.split(' ')[1] == 'dump':
            console.insert(INSERT,db.dumpall(com.split(' ')[2])+'\n')
        if com.split(' ')[1] == 'create':
            db.createdb(com.split(' ')[2])
            console.insert(INSERT,'Db suucefull created!'+'\n')

def execute2():
    execute(txt.get())

window = Tk()
window.title("PyChat 1.6.3 | Console")
window.geometry('600x400')

txt = Entry(window,width=91)
txt.focus()
txt.grid(column=0, row=1)
console = scrolledtext.ScrolledText(window, width=65, height=23)  
console.grid(column=0, row=0) 
btn = Button(window, text="Execute", command=execute2)  
btn.grid(column=1, row=1)

window.mainloop()
