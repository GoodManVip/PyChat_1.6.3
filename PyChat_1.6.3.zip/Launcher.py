#Launcher for pychat
import os,time,random,threading
from tkinter import *
from tkinter import messagebox
from tkinter import scrolledtext

install_list=['pip install python-git']

def start():
    import client

def start_console():
    import console

def start_server():
    import server

def install_libs(libs):
    for lib in libs:
        print('Updating lib: '+lib.split(' ')[2])
        os.system(lib)

def clicked():
    install_libs(install_list)
    import updater

def clicked2():
    rT = threading.Thread(target = start)
    rT.start()

def clicked4():
    rT = threading.Thread(target = start_server)
    rT.start()

def clicked3():
    rT = threading.Thread(target = start_console)
    rT.start()

#Окно
window = Tk()
window.title("PyChat 1.6.3 | Launcher")
window.geometry('350x400')
#Дизайн
lbl = Label(window, text="Новости")  
lbl.grid(column=0, row=0)
news = scrolledtext.ScrolledText(window,width=40,height=10)
news.grid(column=0, row=1)
btn = Button(window, text="Обновить PyChat", command=clicked)  
btn.grid(column=0, row=2)
btn2 = Button(window, text="Запуск PyChat", command=clicked2)  
btn2.grid(column=0, row=3)
btn3 = Button(window, text="Запуск консоли", command=clicked3)  
btn3.grid(column=0, row=4)
btn4 = Button(window, text="Запуск PyChat Server", command=clicked4)  
btn4.grid(column=0, row=5)
#Функционал
news.insert(INSERT, 'PyChat 1.6.3\n 1.Добавлены команды /say и /rules\n 2.Исправленны ошибки\n 3.Запущен ГЛОБАЛЬНЫЙ сервер по адрессу: 62.113.115.141\n 4.Добавлена консоль\n 5.Добавлен графический лаунчер')

window.mainloop()
